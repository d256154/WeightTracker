module.exports = {
	extends: [ "reverentgeek/node" ]
};